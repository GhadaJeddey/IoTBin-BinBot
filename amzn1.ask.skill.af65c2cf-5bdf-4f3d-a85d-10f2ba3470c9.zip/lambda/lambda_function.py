# -*- coding: utf-8 -*-

# This sample demonstrates handling intents from an Alexa skill using the Alexa Skills Kit SDK for Python.
# Please visit https://alexa.design/cookbook for additional examples on implementing slots, dialog management,
# session persistence, api calls, and more.
# This sample is built using the handler classes approach in skill builder.
import logging
import paho.mqtt.client as mqtt
import ask_sdk_core.utils as ask_utils
import time 

from ask_sdk_core.skill_builder import SkillBuilder
from ask_sdk_core.dispatch_components import AbstractRequestHandler
from ask_sdk_core.dispatch_components import AbstractExceptionHandler
from ask_sdk_core.handler_input import HandlerInput

from ask_sdk_model import Response

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

MQTT_BROKER = "broker.emqx.io"
MQTT_PORT = 1883
MQTT_TOPIC1 = "smartbin/lid"
MQTT_TOPIC2 = "smartbin/status"
retrieved_msg = None 
client = mqtt.Client()
latest_status_message = None



def on_message(client, userdata, message):
    """Callback function to process received MQTT messages."""
    global latest_status_message
    latest_status_message = message.payload.decode()

def connect_and_subscribe():
    """Connect to MQTT broker and subscribe to topics."""
    try:
        global client
        client.connect(MQTT_BROKER, MQTT_PORT, 60)
        client.on_message = on_message
        client.subscribe(MQTT_TOPIC2)
        client.loop_start()
        return True
    except Exception as e:
        return False

def publish_mqtt_msg(msg):
    """Publish a message to the MQTT broker."""
    try:
        global client
        pub = client.publish(MQTT_TOPIC1, msg)
        if pub.rc == mqtt.MQTT_ERR_SUCCESS:
            return "Publish State: successful"
        else:
            return "Publish State: failed"
    except Exception as e:
        return "Publish State: failed"


class LaunchRequestHandler(AbstractRequestHandler):
    """Handler for Skill Launch."""
    def can_handle(self, handler_input):
        return ask_utils.is_request_type("LaunchRequest")(handler_input)

    def handle(self, handler_input):
        speak_output = "Welcome to Smart Bin."
        if connect_and_subscribe():
            speak_output += " What would you like to do?"
        else:
            speak_output += " Please try again later."
        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
        )

class OpenBinIntentHandler(AbstractRequestHandler):
    """Handler for OpenBinIntent."""
    def can_handle(self, handler_input):
        return ask_utils.is_intent_name("OpenBinIntent")(handler_input)

    def handle(self, handler_input):
        speak_output = "The bin lid is now open. "
        publish_mqtt_msg("open")
        return (
            handler_input.response_builder
                .speak(speak_output)
                .response
        )

class CheckBinStatusIntentHandler(AbstractRequestHandler):
    """Handler for CheckBinStatusIntent."""
    def can_handle(self, handler_input):
        return ask_utils.is_intent_name("CheckBinStatusIntent")(handler_input)

    def handle(self, handler_input):
        global latest_status_message
        if latest_status_message:
            speak_output = f"The bin status is: {latest_status_message}."
        else:
            speak_output = "I have not received any bin status updates yet."
        return (
            handler_input.response_builder
                .speak(speak_output)
                .response
        )

class HelloWorldIntentHandler(AbstractRequestHandler):
    """Handler for Hello World Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("HelloWorldIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speak_output = "Hello World!"

        return (
            handler_input.response_builder
                .speak(speak_output)
                # .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )

class HelpIntentHandler(AbstractRequestHandler):
    """Handler for Help Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("AMAZON.HelpIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speak_output = "You can say hello to me! How can I help?"

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
        )

class CancelOrStopIntentHandler(AbstractRequestHandler):
    """Single handler for Cancel and Stop Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return (ask_utils.is_intent_name("AMAZON.CancelIntent")(handler_input) or
                ask_utils.is_intent_name("AMAZON.StopIntent")(handler_input))

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speak_output = "Goodbye!"

        return (
            handler_input.response_builder
                .speak(speak_output)
                .response
        )

class FallbackIntentHandler(AbstractRequestHandler):
    """Single handler for Fallback Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("AMAZON.FallbackIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        logger.info("In FallbackIntentHandler")
        speech = "Hmm, I'm not sure. You can say Hello or Help. What would you like to do?"
        reprompt = "I didn't catch that. What can I help you with?"

        return handler_input.response_builder.speak(speech).ask(reprompt).response

class SessionEndedRequestHandler(AbstractRequestHandler):
    """Handler for Session End."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_request_type("SessionEndedRequest")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response

        # Any cleanup logic goes here.

        return handler_input.response_builder.response





class CatchAllExceptionHandler(AbstractExceptionHandler):
    """Generic error handling to capture any syntax or routing errors. If you receive an error
    stating the request handler chain is not found, you have not implemented a handler for
    the intent being invoked or included it in the skill builder below.
    """
    def can_handle(self, handler_input, exception):
        # type: (HandlerInput, Exception) -> bool
        return True

    def handle(self, handler_input, exception):
        # type: (HandlerInput, Exception) -> Response
        logger.error(exception, exc_info=True)

        speak_output = "Sorry, I had trouble doing what you asked. Please try again."

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
        )

# The SkillBuilder object acts as the entry point for your skill, routing all request and response
# payloads to the handlers above. Make sure any new handlers or interceptors you've
# defined are included below. The order matters - they're processed top to bottom.


sb = SkillBuilder()

sb.add_request_handler(LaunchRequestHandler())
sb.add_request_handler(HelloWorldIntentHandler())
sb.add_request_handler(HelpIntentHandler())
sb.add_request_handler(CancelOrStopIntentHandler())
sb.add_request_handler(FallbackIntentHandler())
sb.add_request_handler(SessionEndedRequestHandler())
#sb.add_request_handler(IntentReflectorHandler()) # make sure IntentReflectorHandler is last so it doesn't override your custom intent handlers
sb.add_request_handler(OpenBinIntentHandler())
sb.add_request_handler(CheckBinStatusIntentHandler())

sb.add_exception_handler(CatchAllExceptionHandler())

lambda_handler = sb.lambda_handler()




class CheckBinStatusIntentHandler(AbstractRequestHandler):
    """Handler for CheckBinStatusIntent."""
    def can_handle(self, handler_input):
        return ask_utils.is_intent_name("CheckBinStatusIntent")(handler_input)

    def handle(self, handler_input):
        # Retrieve the bin status from the subscribed MQTT topic
        bin_status = retrieve_mqtt_msg()

        if bin_status:
            speak_output = f"The bin is {bin_status}."
        else:
            speak_output = "Sorry, I couldn't retrieve the bin status at this time."

        return (
            handler_input.response_builder
                .speak(speak_output)
                .response
        )

